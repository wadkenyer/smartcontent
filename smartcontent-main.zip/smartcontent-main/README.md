# smartcontent
SmartContent is a Web3 app for content creators offering AI-powered writing, design, plagiarism checks, and secure content ownership via the Pi Network blockchain.
